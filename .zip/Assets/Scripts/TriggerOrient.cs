using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerOrient : MonoBehaviour
{
    enum Orientation { Left, Right, Forward, Backward }

    [SerializeField] Orientation orientation;

    public Vector3 TurnOrientation
    {
        get
        {
            switch (orientation)
            {
                case Orientation.Left:
                    return Vector3.left;
                case Orientation.Right:
                    return Vector3.right;
                case Orientation.Forward:
                    return Vector3.forward;
                case Orientation.Backward:
                    return Vector3.back;
            }

            return Vector3.zero;
        }

    }
}
