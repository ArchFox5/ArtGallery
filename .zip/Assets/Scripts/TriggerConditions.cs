using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerConditions : MonoBehaviour
{
    enum ObjectCondition { LastStep, CycleStatueLeft, CycleStatueRight, None }

    [SerializeField] ObjectCondition objectCondition;
    public bool IsLastStep => objectCondition == ObjectCondition.LastStep;

    public bool IsCycleStatueLeft => objectCondition == ObjectCondition.CycleStatueLeft;
    public bool IsCycleStatueRight => objectCondition == ObjectCondition.CycleStatueRight;

}
