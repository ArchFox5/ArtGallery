using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

public class ImageLoader : MonoBehaviour
{
    enum ImageTypeSource { File, URL };
    [SerializeField] Material[] Images = null;
    [SerializeField] ImageTypeSource ImageType = ImageTypeSource.URL;
    [SerializeField] string[] imageUrls = new string[0];
    //"https://steamcdn-a.akamaihd.net/steam/apps/895870/ss_c8ad80c90e1c1c3cb7ac43e36dab2cf08e40d1ca.1920x1080.jpg?t=1558092377";
    // https://www.artic.edu/iiif/2/0675f9a9-1a7b-c90a-3bb6-7f7be2afb678/full/1686,/0/default.jpg
    [SerializeField] Renderer tRenderer;

    int currentImage = 0;
    // Start is called before the first frame update
    void Start()
    {
        if (ImageType == ImageTypeSource.URL)
            StartCoroutine(LoadImage());
        else if (ImageType == ImageTypeSource.File)
        {
            SetImage();
        }
    }

    private void OnMouseDown()
    {
        if (ImageType == ImageTypeSource.URL &&
                currentImage < imageUrls.Length - 1)
        {
            currentImage++;

        }
        else if (ImageType == ImageTypeSource.File
            && currentImage < Images.Length - 1)
        {
            currentImage++;

        }
        else
        {
            currentImage = 0;
        }
        Debug.Log(currentImage);
        if (ImageType == ImageTypeSource.URL)
        {
            StartCoroutine(LoadImage());
        }
        else
            SetImage();
    }

    private void SetImage()
    {
        tRenderer.material.color = Color.black;
        tRenderer.material = Images[currentImage];
    }

    private IEnumerator LoadImage()
    {
        Debug.Log("Loading..");

        UnityWebRequest request = UnityWebRequestTexture.GetTexture(imageUrls[currentImage]);
        yield return request.SendWebRequest();
        if (request.result == UnityWebRequest.Result.ConnectionError)
        {
            Debug.Log(request.error);
        }
        else
        {
            tRenderer.material.color = Color.white;
            var texture = DownloadHandlerTexture.GetContent(request);
            tRenderer.material.mainTexture = texture;
        }

        Debug.Log("Loaded");

    }

    // Update is called once per frame
    void Update()
    {

    }
}
