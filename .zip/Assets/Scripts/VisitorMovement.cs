using System;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;


public class VisitorMovement : MonoBehaviour
{
    [SerializeField] float delay;
    [SerializeField] float movement;
    [SerializeField] MovementState movementState = MovementState.Entering;
    [SerializeField] GameObject statue;
    enum MovementState
    {
        Entering, Stand, Move, Positioning, FaceObject, FacingObject,
        LookAtObject, ResumePosition,
        ResumingPosition,
        CycleStatue
    }


    private float _time = 0;
    private Vector3 stoppingPoint = Vector3.zero;
    private Vector3 turnOrientation = Vector3.zero;
   
    private bool IsLastStep;
    private bool isStatueLeft;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (_time < delay)
        {
            _time += Time.deltaTime;
        }


        switch (movementState)
        {
            case MovementState.Entering:
                _time = 0;
                movementState = MovementState.Move;
                break;
            case MovementState.Move:
                if (_time >= delay)
                {
                    transform.Translate(Vector3.forward * movement);
                    Debug.Log(transform.position);
                    _time = 0;
                }
                break;
            case MovementState.Positioning:
                if (transform.position.z >= stoppingPoint.z)
                {
                    movementState = MovementState.FaceObject;
                }
                else
                {
                    if (_time >= delay)
                    {
                        transform.Translate(Vector3.forward * movement);
                        _time = 0;
                    }
                }

                break;
            case MovementState.FaceObject:
                // Rotate using a CoRoutine
                StartCoroutine(FaceObject(turnOrientation));

                break;
            case MovementState.CycleStatue:
                StartCoroutine(CycleStatue());
                break;
            case MovementState.LookAtObject:
                // Coroutine to Wait
                movementState = MovementState.ResumingPosition;
                StartCoroutine(WaitAndGoToNextState(MovementState.ResumePosition, 5f));
                _time = 0;

                break;
            case MovementState.ResumePosition:
                // Coroutine to reverse the rotation
                StartCoroutine(FacePath(turnOrientation));
                
                _time = 0;
                break;

        }

    }

    private IEnumerator CycleStatue()
    {
        float loctime = 0f;
        float maxDegrees = 360f;
        float angleIncrement = 1;
        WaitForSeconds waitForSeconds = new WaitForSeconds(.01f);
        movementState = MovementState.FacingObject;
        Vector3 Axis = statue.transform.position;
        isStatueLeft = false;
        for (int totDegrees = 0; totDegrees < maxDegrees;)
        {

            if (loctime < delay)
            {
                loctime++;
                yield return waitForSeconds;
            }
            else
            {
                totDegrees++;
                transform.RotateAround(Axis, Vector3.up, angleIncrement);
                loctime = 0;
                yield return waitForSeconds;
            }
        }
        
        movementState = MovementState.LookAtObject;

        _time = 0;

    }

    private IEnumerator WaitAndGoToNextState(MovementState next, float delay)
    {
        yield return new WaitForSeconds(delay);
        movementState = next;
    }

    private IEnumerator FaceObject(Vector3 turnOrientation)
    {
        float loctime = 0f;
        float maxDegrees = 90f;
        float angleIncrement = turnOrientation == Vector3.left ? -1 : 1;
        WaitForSeconds waitForSeconds = new WaitForSeconds(.01f);
        movementState = MovementState.FacingObject;
        for (int totDegrees = 0; totDegrees < maxDegrees;)
        {

            if (loctime < delay)
            {
                loctime++;
                yield return waitForSeconds;
            }
            else
            {
                totDegrees++;
                transform.Rotate(Vector3.up, angleIncrement);
                loctime = 0;
                yield return waitForSeconds;
            }
        }
        movementState = MovementState.LookAtObject;
        if (isStatueLeft)
        {
            movementState = MovementState.CycleStatue;
        }
        _time = 0;
    }


    private IEnumerator FacePath(Vector3 turnOrientation)
    {
        float loctime = 0f;
        float maxDegrees = 90;
        float angleIncrement = turnOrientation == Vector3.left ? 1 : -1;
        WaitForSeconds waitForSeconds = new WaitForSeconds(.01f);
        movementState = MovementState.ResumingPosition;
        for (int totDegrees = 0; totDegrees < maxDegrees;)
        {

            if (loctime < delay)
            {
                loctime++;
                yield return waitForSeconds;
            }
            else
            {
                totDegrees++;
                transform.Rotate(Vector3.up, angleIncrement);
                loctime = 0;
                yield return waitForSeconds;
            }
        }
        movementState = MovementState.Move;
        if (IsLastStep)
        {
            IsLastStep = false;
            movementState = MovementState.Stand;
        }
        _time = 0;
    }
    private void OnTriggerEnter(Collider other)
    {
        Debug.LogFormat("Triggered by {0}", other.name);

        if (movementState == MovementState.Move && other.CompareTag("FloorTrigger"))
        {
            Bounds bestViewing =
            other.GetComponent<Collider>().bounds;

            TriggerOrient triggerOrient = other.GetComponent<TriggerOrient>();
            if (triggerOrient != null)
            {
                turnOrientation =
                triggerOrient.TurnOrientation;
            }

            Vector3 modPosition = transform.position;
            modPosition.z += bestViewing.size.z;
            stoppingPoint = modPosition;

            movementState = MovementState.Positioning;
            TriggerConditions triggerConditions = other.GetComponent<TriggerConditions>();
            if (triggerConditions != null)
            {
                IsLastStep = triggerConditions.IsLastStep;
                if (!IsLastStep)
                {
                    isStatueLeft = triggerConditions.IsCycleStatueLeft;
                }
            }



        }


    }

    private void OnTriggerExit(Collider other)
    {
        Debug.LogFormat("Exited trigger area: {0}", other.name);
    }
}
