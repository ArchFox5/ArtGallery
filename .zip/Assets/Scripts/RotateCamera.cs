using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateCamera : MonoBehaviour
{
    [SerializeField] private GameObject OrbitAround;
    [SerializeField] private float increment;
    [SerializeField] private float delay;
    // Start is called before the first frame update

    private Vector3 startingPosition;
    private Vector3 Axis;
    private void Start()
    {
        startingPosition = transform.position;
        Axis = OrbitAround.transform.position;

    }
    private float _time = 0;
    private bool returnedToStart = false;
    // Update is called once per frame
    void Update()
    {
        if (!returnedToStart)
        {
            if (_time < delay)
            {
                _time += delay;
            }
            else
            {
                float distanceFromAxis = Vector3.Distance(transform.position, Axis);
                Debug.Log(distanceFromAxis);
                transform.RotateAround(Axis, Vector3.up, increment);
                if (transform.position == startingPosition)
                {
                    returnedToStart = true;
                    transform.position = startingPosition;
                }
                _time = 0;
            }
        }
    }
    private void LateUpdate()
    {

    }
}
